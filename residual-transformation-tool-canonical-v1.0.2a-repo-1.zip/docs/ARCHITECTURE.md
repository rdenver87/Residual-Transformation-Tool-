# Architecture

## Condensed canonical workbook structure

- README
- Inputs
- Research_Runs
- Residuals
- Settings
- Packages
- Validation_Loop
- Governance
- Deployment
- Dashboard
- Subjects
- Subject_Comparison
- Preflight_Audit

## Workflow

measurement -> residual -> transformation -> validation -> governance -> deployment

## Status models

### Setting status
- RESEARCH
- CANDIDATE
- LOCKED
- DEPLOYED
- RETIRED

### Governance status
- NONE
- UNDER_REVIEW
- APPROVED
- RATIFIED
- REJECTED

### Validation status
- UNTESTED
- TESTING
- PASS
- FAIL
- HOLD

### Release status
- DRAFT
- INTERNAL
- APPROVED
- EXECUTABLE
- ROLLED_BACK
