# Repository Use

## Recommended default
Use the canonical workbook in `workbooks/canonical/`.

## Recommended first checks
1. Open `Preflight_Audit`
2. Review `Dashboard`
3. Confirm the current blocker
4. Review `Research_Runs`
5. Only trust promotion and deployment interpretation after critical checks pass

## Known open blocker
`SET-003` remains unresolved in the current sample line.
