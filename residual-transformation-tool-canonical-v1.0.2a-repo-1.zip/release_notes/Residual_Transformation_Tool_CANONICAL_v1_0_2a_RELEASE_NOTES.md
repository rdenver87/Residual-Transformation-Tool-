# Residual Transformation Tool — CANONICAL v1.0.2a Release Notes

## Canonical release decision
This release is canonized as the authoritative framework baseline.

## Canonicalized
- condensed v1.0 architecture
- subject-aware extension
- subject comparison extension
- preflight audit / hardening layer
- current-master usage pattern

## Not claimed complete
- SET-003 remains a live unresolved blocker for executable readiness
- current sample-state is not canonized as validated completion

## Recommended naming going forward
- v1.0.2b for hardening-only tweaks
- v1.0.3 for additive but compatible extensions
- v1.1 for meaningful workflow expansion
- v2.0 only for structural redesign
